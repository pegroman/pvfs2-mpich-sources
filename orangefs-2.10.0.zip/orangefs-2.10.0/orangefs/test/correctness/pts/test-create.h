#ifndef _TEST_CREATE_H
#define _TEST_CREATE_H

#include "pvfs2-types.h"
int test_create(MPI_Comm *comm, int rank, char *buf, void *params);

#endif
