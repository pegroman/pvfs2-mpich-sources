#ifndef TEST_ENCODE_BASIC_H
#define TEST_ENCODE_BASIC_H

int test_encode_basic(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
