#ifndef TEST_EXPLICIT_OFFSET_H
#define TEST_EXPLICIT_OFFSET_H

int test_explicit_offset(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
