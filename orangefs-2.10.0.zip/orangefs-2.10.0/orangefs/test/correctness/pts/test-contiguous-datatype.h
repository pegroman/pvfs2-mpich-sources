#ifndef TEST_CONTIGUOUS_DATATYPE_H
#define TEST_CONTIGUOUS_DATATYPE_H

int test_contiguous_datatype(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
