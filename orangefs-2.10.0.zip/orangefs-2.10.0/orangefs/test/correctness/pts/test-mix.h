#ifndef TEST_MIX_H
#define TEST_MIX_H

int test_mix(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
