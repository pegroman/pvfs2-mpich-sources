#ifndef TEST_REQUEST_INDEXED_H
#define TEST_REQUEST_INDEXED_H

int test_request_indexed(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
