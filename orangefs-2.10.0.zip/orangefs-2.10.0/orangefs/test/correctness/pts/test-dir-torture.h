#ifndef TEST_DIR_TORTURE_H
#define TEST_DIR_TORTURE_H

int test_dir_torture(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
