#ifndef INCLUDE_FINALIZED_H
#define INCLUDE_FINALIZED_H

int test_finalized(MPI_Comm * comm,
		   int rank,
		   char *buf,
		   void *rawparams);

#endif
