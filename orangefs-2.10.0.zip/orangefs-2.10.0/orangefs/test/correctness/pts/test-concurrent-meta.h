#ifndef TEST_CONCURRENT_META_H
#define TEST_CONCURRENT_META_H

int test_concurrent_meta(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
