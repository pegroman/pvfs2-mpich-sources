#ifndef TEST_ROMIO_NONCONTIG_PATTERN2_H
#define TEST_ROMIO_NONCONTIG_PATTERN2_H

int test_romio_noncontig_pattern2(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
