#ifndef TEST_LOOKUP_BENCH_H
#define TEST_LOOKUP_BENCH_H

int test_lookup_bench(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
