#ifndef TEST_WRITE_EOF_H
#define TEST_WRITE_EOF_H

int test_write_eof(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
