#ifndef TEST_REQUEST_CONTIGUOUS_H
#define TEST_REQUEST_CONTIGUOUS_H

int test_request_contiguous(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
