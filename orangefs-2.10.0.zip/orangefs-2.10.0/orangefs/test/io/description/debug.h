
void prtval(long long val, char *s);

void cmpval(long long val, long long exp);

void prtseg(PINT_Request_result *seg, char *s);

void cmpseg(PINT_Request_result *seg, PINT_Request_result *exp);

int request_debug(void);

extern int gossipflag;
