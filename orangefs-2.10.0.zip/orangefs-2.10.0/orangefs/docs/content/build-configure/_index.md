+++
title= "Build and Configure"
weight=100
+++

- [OrangeFS Build Details]({{<relref "Build_OrangeFS">}})
- [OrangeFS Config File]({{<relref "Create_OrangeFS_Configuration_File">}})
- [Advanced Security Build]({{<relref "Setup_Security_(Build)">}})
- [Configure LDAP]({{<relref "Configuring_LDAP_For_Identity_Mapping">}})
- [Results]({{<relref "Results_of_Build_and_Configure">}})

 

 

 

 

 

 

 

 

 

 
