+++
title= "Advanced Configuration"
weight=500
+++

- [OrangeFS Configuration File]({{<relref "admin_ofs_configuration_file">}})
- [Multiple File Systems]({{<relref "OrangeFS_Advanced_Configuration">}})
- [Multiple Server Processes]({{<relref "Multiple_Server_Processes">}})
