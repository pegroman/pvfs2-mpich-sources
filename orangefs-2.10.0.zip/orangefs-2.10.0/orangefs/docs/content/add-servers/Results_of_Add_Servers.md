
+++
title= "Add Server(s) Results"
weight=250
+++

At the end of the Add Servers step, each Server system will include an
OrangeFS installation directory (/opt/orangefs).

If you are using key-based security mode, each Server system will also
include its own private key in /opt/orangefs/etc.

 

 

 

 

 
